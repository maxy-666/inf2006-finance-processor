import boto3
import os

client = boto3.client('quicksight')
ACCOUNT_ID = os.environ['ACCOUNT_ID']
DATASET_ID = os.environ['DATASET_ID']

def lambda_handler(event, context):
    try:
        # Trigger an ingestion (refresh) for the SPICE dataset
        client.create_ingestion(
            DataSetId=DATASET_ID,
            IngestionId=f'refresh-{context.aws_request_id}',
            AwsAccountId=ACCOUNT_ID,
            IngestionType='FULL_REFRESH'
        )
        return {"status": "refresh_started"}
    except Exception as e:
        print(f"Error refreshing dataset: {e}")
        # We return success even on fail so we don't break the whole workflow
        return {"status": "failed", "error": str(e)}
